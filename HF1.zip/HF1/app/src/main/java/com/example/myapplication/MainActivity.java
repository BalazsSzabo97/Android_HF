package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    final EditText szam1 = (EditText)findViewById(R.id.editTextNumber5);
    final EditText szam2 = (EditText)findViewById(R.id.editTextNumber6);
    button plusz = (Button)findViewById(R.id.plusz);
    button minusz = (Button)findViewById(R.id.minusz);
    button szor = (Button)findViewById(R.id.szor);
    button oszt = (Button)findViewById(R.id.oszt);

    plusz.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            try {
                double eredmeny = Double.parseDouble(szam1.getText().toString()) + Double.parseDouble(szam2.getText().toString());
                tv.setText(Double.toString(eredmeny));
            } catch (NumberFormatException e) {
                Context context = getApplicationContext();
                CharSequence text = "Konverzios hiba!";
                int duration = Toast.LENGTH_SHORT;

                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
            }
        }
    });

    minusz.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            try {
                double eredmeny = Double.parseDouble(szam1.getText().toString()) - Double.parseDouble(szam2.getText().toString());
                tv.setText(Double.toString(eredmeny));
            } catch (NumberFormatException e) {
                Context context = getApplicationContext();
                CharSequence text = "Konverzios hiba!";
                int duration = Toast.LENGTH_SHORT;

                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
            }
        }
    });

    szor.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            try {
                double eredmeny = Double.parseDouble(szam1.getText().toString()) * Double.parseDouble(szam2.getText().toString());
                tv.setText(Double.toString(eredmeny));
            } catch (NumberFormatException e) {
                Context context = getApplicationContext();
                CharSequence text = "Konverzios hiba!";
                int duration = Toast.LENGTH_SHORT;

                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
            }
        }
    });

    oszt.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            try {
                double eredmeny = Double.parseDouble(szam1.getText().toString()) / Double.parseDouble(szam2.getText().toString());
                tv.setText(Double.toString(eredmeny));
            } catch (NumberFormatException e) {
                Context context = getApplicationContext();
                CharSequence text = "Konverzios hiba!";
                int duration = Toast.LENGTH_SHORT;

                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
            }
        }
    });

}
}
